To learn more about the font family and its license, visit https://www.fontmirror.com/inter

Copyright (c) 2016-2018 The Inter Project Authors (me@rsms.me).
To know more about the typeface, visit https://rsms.me/inter/.