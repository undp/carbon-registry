exports.handler = async (event) => {
    console.log(`Started with: ${event.body}`)
}